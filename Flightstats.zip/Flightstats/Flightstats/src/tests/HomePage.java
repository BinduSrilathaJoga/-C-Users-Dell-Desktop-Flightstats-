package tests;

public class HomePage {
	WebDriver driver;
	public static void main(String[] args)
	{
		System.out.println("dahda");
		
	}
}
